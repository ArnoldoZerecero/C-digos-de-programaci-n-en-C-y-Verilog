/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Alumnos/Downloads/proyecto-FINAL (1)/proyecto-MEGA-IZI/proyecto_sin_historial/proyecto/bin_BCD.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {1U, 0U};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {256U, 0U};
static int ng5[] = {1, 0};
static unsigned int ng6[] = {4U, 0U};
static unsigned int ng7[] = {3U, 0U};
static int ng8[] = {11, 0};
static int ng9[] = {8, 0};
static int ng10[] = {15, 0};
static int ng11[] = {12, 0};
static int ng12[] = {19, 0};
static int ng13[] = {16, 0};



static void Cont_43_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 4768U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 6488);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 15U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 3);
    t18 = (t0 + 6328);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_44_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 5016U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 6552);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 15U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 3);
    t18 = (t0 + 6344);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_45_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 5264U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 6616);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 15U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 3);
    t18 = (t0 + 6360);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_47_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 5512U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 6376);
    *((int *)t2) = 1;
    t3 = (t0 + 5544);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(48, ng0);

LAB5:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(66, ng0);

LAB14:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 20, 0LL);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 9, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);

LAB12:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(50, ng0);

LAB9:    xsi_set_current_line(51, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 20, 0LL);
    xsi_set_current_line(52, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 9, 0LL);
    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(55, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    goto LAB8;

LAB10:    xsi_set_current_line(58, ng0);

LAB13:    xsi_set_current_line(59, ng0);
    t4 = (t0 + 2568);
    t5 = (t4 + 56U);
    t11 = *((char **)t5);
    t12 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 20, 0LL);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 2728);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 9, 0LL);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3848);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 4, 0LL);
    goto LAB12;

}

static void Always_75_4(char *t0)
{
    char t8[8];
    char t28[8];
    char t29[8];
    char t44[8];
    char t46[8];
    char t47[8];
    char t48[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t45;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    int t55;
    char *t56;
    int t57;
    int t58;
    char *t59;
    int t60;
    int t61;
    int t62;
    int t63;
    int t64;

LAB0:    t1 = (t0 + 5760U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 6392);
    *((int *)t2) = 1;
    t3 = (t0 + 5792);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(76, ng0);

LAB5:    xsi_set_current_line(77, ng0);
    t4 = (t0 + 3048);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 4);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 4);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t8, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t6);
    t13 = *((unsigned int *)t7);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t7);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t8) = 1;

LAB9:    t22 = (t8 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t8);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2888);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t8, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t6);
    t13 = *((unsigned int *)t7);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t7);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB17;

LAB14:    if (t18 != 0)
        goto LAB16;

LAB15:    *((unsigned int *)t8) = 1;

LAB17:    t22 = (t8 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t8);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB18;

LAB19:    xsi_set_current_line(92, ng0);

LAB22:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_lshift(t8, 20, t4, 20, t5, 32);
    t6 = (t0 + 2568);
    xsi_vlogvar_assign_value(t6, t8, 0, 0, 20);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 7);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 7);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = ((char*)((ng6)));
    memset(t28, 0, 8);
    t21 = (t8 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB24;

LAB23:    t22 = (t7 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB24;

LAB27:    if (*((unsigned int *)t8) > *((unsigned int *)t7))
        goto LAB25;

LAB26:    t31 = (t28 + 4);
    t15 = *((unsigned int *)t31);
    t16 = (~(t15));
    t17 = *((unsigned int *)t28);
    t18 = (t17 & t16);
    t19 = (t18 != 0);
    if (t19 > 0)
        goto LAB28;

LAB29:    xsi_set_current_line(100, ng0);

LAB34:    xsi_set_current_line(101, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 7);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 7);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 2568);
    t21 = (t0 + 2568);
    t22 = (t21 + 72U);
    t30 = *((char **)t22);
    t31 = ((char*)((ng8)));
    t32 = ((char*)((ng9)));
    xsi_vlog_convert_partindices(t28, t29, t44, ((int*)(t30)), 2, t31, 32, 1, t32, 32, 1);
    t39 = (t28 + 4);
    t15 = *((unsigned int *)t39);
    t55 = (!(t15));
    t40 = (t29 + 4);
    t16 = *((unsigned int *)t40);
    t57 = (!(t16));
    t58 = (t55 && t57);
    t41 = (t44 + 4);
    t17 = *((unsigned int *)t41);
    t60 = (!(t17));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB35;

LAB36:
LAB30:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 11);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 11);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = ((char*)((ng6)));
    memset(t28, 0, 8);
    t21 = (t8 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB38;

LAB37:    t22 = (t7 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB38;

LAB41:    if (*((unsigned int *)t8) > *((unsigned int *)t7))
        goto LAB39;

LAB40:    t31 = (t28 + 4);
    t15 = *((unsigned int *)t31);
    t16 = (~(t15));
    t17 = *((unsigned int *)t28);
    t18 = (t17 & t16);
    t19 = (t18 != 0);
    if (t19 > 0)
        goto LAB42;

LAB43:    xsi_set_current_line(109, ng0);

LAB48:    xsi_set_current_line(110, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 11);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 11);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 2568);
    t21 = (t0 + 2568);
    t22 = (t21 + 72U);
    t30 = *((char **)t22);
    t31 = ((char*)((ng10)));
    t32 = ((char*)((ng11)));
    xsi_vlog_convert_partindices(t28, t29, t44, ((int*)(t30)), 2, t31, 32, 1, t32, 32, 1);
    t39 = (t28 + 4);
    t15 = *((unsigned int *)t39);
    t55 = (!(t15));
    t40 = (t29 + 4);
    t16 = *((unsigned int *)t40);
    t57 = (!(t16));
    t58 = (t55 && t57);
    t41 = (t44 + 4);
    t17 = *((unsigned int *)t41);
    t60 = (!(t17));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB49;

LAB50:
LAB44:    xsi_set_current_line(113, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 15);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 15);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = ((char*)((ng6)));
    memset(t28, 0, 8);
    t21 = (t8 + 4);
    if (*((unsigned int *)t21) != 0)
        goto LAB52;

LAB51:    t22 = (t7 + 4);
    if (*((unsigned int *)t22) != 0)
        goto LAB52;

LAB55:    if (*((unsigned int *)t8) > *((unsigned int *)t7))
        goto LAB53;

LAB54:    t31 = (t28 + 4);
    t15 = *((unsigned int *)t31);
    t16 = (~(t15));
    t17 = *((unsigned int *)t28);
    t18 = (t17 & t16);
    t19 = (t18 != 0);
    if (t19 > 0)
        goto LAB56;

LAB57:    xsi_set_current_line(118, ng0);

LAB62:    xsi_set_current_line(119, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 15);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 15);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 2568);
    t21 = (t0 + 2568);
    t22 = (t21 + 72U);
    t30 = *((char **)t22);
    t31 = ((char*)((ng12)));
    t32 = ((char*)((ng13)));
    xsi_vlog_convert_partindices(t28, t29, t44, ((int*)(t30)), 2, t31, 32, 1, t32, 32, 1);
    t39 = (t28 + 4);
    t15 = *((unsigned int *)t39);
    t55 = (!(t15));
    t40 = (t29 + 4);
    t16 = *((unsigned int *)t40);
    t57 = (!(t16));
    t58 = (t55 && t57);
    t41 = (t44 + 4);
    t17 = *((unsigned int *)t41);
    t60 = (!(t17));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB63;

LAB64:
LAB58:
LAB20:
LAB12:    goto LAB2;

LAB8:    t21 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(81, ng0);

LAB13:    xsi_set_current_line(82, ng0);
    t30 = (t0 + 1528U);
    t31 = *((char **)t30);
    memset(t29, 0, 8);
    t30 = (t29 + 4);
    t32 = (t31 + 4);
    t33 = *((unsigned int *)t31);
    t34 = (t33 >> 0);
    *((unsigned int *)t29) = t34;
    t35 = *((unsigned int *)t32);
    t36 = (t35 >> 0);
    *((unsigned int *)t30) = t36;
    t37 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t37 & 255U);
    t38 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t38 & 255U);
    t39 = ((char*)((ng3)));
    xsi_vlogtype_concat(t28, 27, 27, 2U, t39, 19, t29, 8);
    t40 = (t0 + 2568);
    xsi_vlogvar_assign_value(t40, t28, 0, 0, 20);
    xsi_set_current_line(83, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 8);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 8);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 3208);
    xsi_vlogvar_assign_value(t7, t8, 0, 0, 4);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 12);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 12);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 3528);
    xsi_vlogvar_assign_value(t7, t8, 0, 0, 4);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t8, 0, 8);
    t5 = (t8 + 4);
    t6 = (t4 + 4);
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 16);
    *((unsigned int *)t8) = t10;
    t11 = *((unsigned int *)t6);
    t12 = (t11 >> 16);
    *((unsigned int *)t5) = t12;
    t13 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t13 & 15U);
    t14 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t14 & 15U);
    t7 = (t0 + 3848);
    xsi_vlogvar_assign_value(t7, t8, 0, 0, 4);
    goto LAB12;

LAB16:    t21 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(88, ng0);

LAB21:    xsi_set_current_line(89, ng0);
    t30 = ((char*)((ng3)));
    t31 = (t0 + 2408);
    t32 = (t31 + 56U);
    t39 = *((char **)t32);
    memset(t29, 0, 8);
    t40 = (t29 + 4);
    t41 = (t39 + 4);
    t33 = *((unsigned int *)t39);
    t34 = (t33 >> 0);
    *((unsigned int *)t29) = t34;
    t35 = *((unsigned int *)t41);
    t36 = (t35 >> 0);
    *((unsigned int *)t40) = t36;
    t37 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t37 & 524287U);
    t38 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t38 & 524287U);
    xsi_vlogtype_concat(t28, 20, 20, 2U, t29, 19, t30, 1);
    t42 = (t0 + 2568);
    xsi_vlogvar_assign_value(t42, t28, 0, 0, 20);
    goto LAB20;

LAB24:    t30 = (t28 + 4);
    *((unsigned int *)t28) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB26;

LAB25:    *((unsigned int *)t28) = 1;
    goto LAB26;

LAB28:    xsi_set_current_line(96, ng0);

LAB31:    xsi_set_current_line(97, ng0);
    t32 = (t0 + 2408);
    t39 = (t32 + 56U);
    t40 = *((char **)t39);
    memset(t29, 0, 8);
    t41 = (t29 + 4);
    t42 = (t40 + 4);
    t20 = *((unsigned int *)t40);
    t23 = (t20 >> 7);
    *((unsigned int *)t29) = t23;
    t24 = *((unsigned int *)t42);
    t25 = (t24 >> 7);
    *((unsigned int *)t41) = t25;
    t26 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t26 & 15U);
    t27 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t27 & 15U);
    t43 = ((char*)((ng7)));
    memset(t44, 0, 8);
    xsi_vlog_unsigned_add(t44, 4, t29, 4, t43, 4);
    t45 = (t0 + 2568);
    t49 = (t0 + 2568);
    t50 = (t49 + 72U);
    t51 = *((char **)t50);
    t52 = ((char*)((ng8)));
    t53 = ((char*)((ng9)));
    xsi_vlog_convert_partindices(t46, t47, t48, ((int*)(t51)), 2, t52, 32, 1, t53, 32, 1);
    t54 = (t46 + 4);
    t33 = *((unsigned int *)t54);
    t55 = (!(t33));
    t56 = (t47 + 4);
    t34 = *((unsigned int *)t56);
    t57 = (!(t34));
    t58 = (t55 && t57);
    t59 = (t48 + 4);
    t35 = *((unsigned int *)t59);
    t60 = (!(t35));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB32;

LAB33:    goto LAB30;

LAB32:    t36 = *((unsigned int *)t48);
    t62 = (t36 + 0);
    t37 = *((unsigned int *)t46);
    t38 = *((unsigned int *)t47);
    t63 = (t37 - t38);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t45, t44, t62, *((unsigned int *)t47), t64);
    goto LAB33;

LAB35:    t18 = *((unsigned int *)t44);
    t62 = (t18 + 0);
    t19 = *((unsigned int *)t28);
    t20 = *((unsigned int *)t29);
    t63 = (t19 - t20);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t7, t8, t62, *((unsigned int *)t29), t64);
    goto LAB36;

LAB38:    t30 = (t28 + 4);
    *((unsigned int *)t28) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB40;

LAB39:    *((unsigned int *)t28) = 1;
    goto LAB40;

LAB42:    xsi_set_current_line(105, ng0);

LAB45:    xsi_set_current_line(106, ng0);
    t32 = (t0 + 2408);
    t39 = (t32 + 56U);
    t40 = *((char **)t39);
    memset(t29, 0, 8);
    t41 = (t29 + 4);
    t42 = (t40 + 4);
    t20 = *((unsigned int *)t40);
    t23 = (t20 >> 11);
    *((unsigned int *)t29) = t23;
    t24 = *((unsigned int *)t42);
    t25 = (t24 >> 11);
    *((unsigned int *)t41) = t25;
    t26 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t26 & 15U);
    t27 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t27 & 15U);
    t43 = ((char*)((ng7)));
    memset(t44, 0, 8);
    xsi_vlog_unsigned_add(t44, 4, t29, 4, t43, 4);
    t45 = (t0 + 2568);
    t49 = (t0 + 2568);
    t50 = (t49 + 72U);
    t51 = *((char **)t50);
    t52 = ((char*)((ng10)));
    t53 = ((char*)((ng11)));
    xsi_vlog_convert_partindices(t46, t47, t48, ((int*)(t51)), 2, t52, 32, 1, t53, 32, 1);
    t54 = (t46 + 4);
    t33 = *((unsigned int *)t54);
    t55 = (!(t33));
    t56 = (t47 + 4);
    t34 = *((unsigned int *)t56);
    t57 = (!(t34));
    t58 = (t55 && t57);
    t59 = (t48 + 4);
    t35 = *((unsigned int *)t59);
    t60 = (!(t35));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB46;

LAB47:    goto LAB44;

LAB46:    t36 = *((unsigned int *)t48);
    t62 = (t36 + 0);
    t37 = *((unsigned int *)t46);
    t38 = *((unsigned int *)t47);
    t63 = (t37 - t38);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t45, t44, t62, *((unsigned int *)t47), t64);
    goto LAB47;

LAB49:    t18 = *((unsigned int *)t44);
    t62 = (t18 + 0);
    t19 = *((unsigned int *)t28);
    t20 = *((unsigned int *)t29);
    t63 = (t19 - t20);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t7, t8, t62, *((unsigned int *)t29), t64);
    goto LAB50;

LAB52:    t30 = (t28 + 4);
    *((unsigned int *)t28) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB54;

LAB53:    *((unsigned int *)t28) = 1;
    goto LAB54;

LAB56:    xsi_set_current_line(114, ng0);

LAB59:    xsi_set_current_line(115, ng0);
    t32 = (t0 + 2408);
    t39 = (t32 + 56U);
    t40 = *((char **)t39);
    memset(t29, 0, 8);
    t41 = (t29 + 4);
    t42 = (t40 + 4);
    t20 = *((unsigned int *)t40);
    t23 = (t20 >> 15);
    *((unsigned int *)t29) = t23;
    t24 = *((unsigned int *)t42);
    t25 = (t24 >> 15);
    *((unsigned int *)t41) = t25;
    t26 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t26 & 15U);
    t27 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t27 & 15U);
    t43 = ((char*)((ng7)));
    memset(t44, 0, 8);
    xsi_vlog_unsigned_add(t44, 4, t29, 4, t43, 4);
    t45 = (t0 + 2568);
    t49 = (t0 + 2568);
    t50 = (t49 + 72U);
    t51 = *((char **)t50);
    t52 = ((char*)((ng12)));
    t53 = ((char*)((ng13)));
    xsi_vlog_convert_partindices(t46, t47, t48, ((int*)(t51)), 2, t52, 32, 1, t53, 32, 1);
    t54 = (t46 + 4);
    t33 = *((unsigned int *)t54);
    t55 = (!(t33));
    t56 = (t47 + 4);
    t34 = *((unsigned int *)t56);
    t57 = (!(t34));
    t58 = (t55 && t57);
    t59 = (t48 + 4);
    t35 = *((unsigned int *)t59);
    t60 = (!(t35));
    t61 = (t58 && t60);
    if (t61 == 1)
        goto LAB60;

LAB61:    goto LAB58;

LAB60:    t36 = *((unsigned int *)t48);
    t62 = (t36 + 0);
    t37 = *((unsigned int *)t46);
    t38 = *((unsigned int *)t47);
    t63 = (t37 - t38);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t45, t44, t62, *((unsigned int *)t47), t64);
    goto LAB61;

LAB63:    t18 = *((unsigned int *)t44);
    t62 = (t18 + 0);
    t19 = *((unsigned int *)t28);
    t20 = *((unsigned int *)t29);
    t63 = (t19 - t20);
    t64 = (t63 + 1);
    xsi_vlogvar_assign_value(t7, t8, t62, *((unsigned int *)t29), t64);
    goto LAB64;

}

static void Always_123_5(char *t0)
{
    char t4[8];
    char t8[8];
    char t17[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;

LAB0:    t1 = (t0 + 6008U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 6408);
    *((int *)t2) = 1;
    t3 = (t0 + 6040);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(124, ng0);

LAB5:    xsi_set_current_line(125, ng0);
    t5 = (t0 + 2888);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t10 = (t7 + 4);
    t11 = *((unsigned int *)t7);
    t12 = (t11 >> 8);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t10);
    t15 = (t14 >> 8);
    t16 = (t15 & 1);
    *((unsigned int *)t9) = t16;
    t18 = (t0 + 2888);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memset(t17, 0, 8);
    t21 = (t17 + 4);
    t22 = (t20 + 4);
    t23 = *((unsigned int *)t20);
    t24 = (t23 >> 0);
    *((unsigned int *)t17) = t24;
    t25 = *((unsigned int *)t22);
    t26 = (t25 >> 0);
    *((unsigned int *)t21) = t26;
    t27 = *((unsigned int *)t17);
    *((unsigned int *)t17) = (t27 & 255U);
    t28 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t28 & 255U);
    xsi_vlogtype_concat(t4, 9, 9, 2U, t17, 8, t8, 1);
    t29 = (t0 + 2728);
    xsi_vlogvar_assign_value(t29, t4, 0, 0, 9);
    goto LAB2;

}


extern void work_m_00000000000681885921_2598513641_init()
{
	static char *pe[] = {(void *)Cont_43_0,(void *)Cont_44_1,(void *)Cont_45_2,(void *)Always_47_3,(void *)Always_75_4,(void *)Always_123_5};
	xsi_register_didat("work_m_00000000000681885921_2598513641", "isim/top_tb_isim_beh.exe.sim/work/m_00000000000681885921_2598513641.didat");
	xsi_register_executes(pe);
}
