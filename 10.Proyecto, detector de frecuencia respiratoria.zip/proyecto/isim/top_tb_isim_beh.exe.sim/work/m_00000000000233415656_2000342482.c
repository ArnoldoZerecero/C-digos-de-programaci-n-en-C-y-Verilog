/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Alumnos/Downloads/proyecto-FINAL (1)/proyecto-MEGA-IZI/proyecto_sin_historial/proyecto/alarma.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {150000000U, 0U};
static unsigned int ng3[] = {149999999U, 0U};
static unsigned int ng4[] = {1U, 0U};
static int ng5[] = {1, 0};
static unsigned int ng6[] = {8U, 0U};
static unsigned int ng7[] = {0U, 0U};
static unsigned int ng8[] = {10U, 0U};



static void Cont_45_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 4928U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 5856);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 5744);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_47_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 5176U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 5760);
    *((int *)t2) = 1;
    t3 = (t0 + 5208);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(48, ng0);

LAB5:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(57, ng0);

LAB10:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB11;

LAB12:    xsi_set_current_line(66, ng0);

LAB15:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 28, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 8, 0LL);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 8, 0LL);

LAB13:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(50, ng0);

LAB9:    xsi_set_current_line(51, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    xsi_set_current_line(52, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 28, 0LL);
    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    goto LAB8;

LAB11:    xsi_set_current_line(59, ng0);

LAB14:    xsi_set_current_line(60, ng0);
    t4 = (t0 + 2888);
    t5 = (t4 + 56U);
    t11 = *((char **)t5);
    t12 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 28, 0LL);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3688);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 8, 0LL);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3848);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4008);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 8, 0LL);
    goto LAB13;

}

static void Always_75_2(char *t0)
{
    char t8[8];
    char t29[8];
    char t41[8];
    char t42[8];
    char t47[8];
    char t82[8];
    char t83[8];
    char t84[8];
    char t89[8];
    char t103[8];
    char t111[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    char *t81;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    char *t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    char *t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    char *t110;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    char *t115;
    char *t116;
    char *t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    char *t125;
    char *t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    int t135;
    int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    char *t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    char *t149;
    char *t150;

LAB0:    t1 = (t0 + 5424U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 5776);
    *((int *)t2) = 1;
    t3 = (t0 + 5456);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(76, ng0);

LAB5:    xsi_set_current_line(77, ng0);
    t4 = (t0 + 3368);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng2)));
    memset(t8, 0, 8);
    t9 = (t6 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB7;

LAB6:    t10 = (t7 + 4);
    if (*((unsigned int *)t10) != 0)
        goto LAB7;

LAB10:    if (*((unsigned int *)t6) < *((unsigned int *)t7))
        goto LAB8;

LAB9:    t12 = (t8 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t8);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB11;

LAB12:    xsi_set_current_line(104, ng0);
    t2 = (t0 + 2328U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t13 = *((unsigned int *)t2);
    t14 = (~(t13));
    t15 = *((unsigned int *)t3);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB30;

LAB31:    xsi_set_current_line(111, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t13 = *((unsigned int *)t2);
    t14 = (~(t13));
    t15 = *((unsigned int *)t3);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB34;

LAB35:    xsi_set_current_line(128, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 1528U);
    t6 = *((char **)t5);
    t5 = ((char*)((ng8)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 8, t6, 6, t5, 8);
    memset(t29, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB68;

LAB67:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB68;

LAB71:    if (*((unsigned int *)t4) > *((unsigned int *)t8))
        goto LAB70;

LAB69:    *((unsigned int *)t29) = 1;

LAB70:    memset(t41, 0, 8);
    t11 = (t29 + 4);
    t13 = *((unsigned int *)t11);
    t14 = (~(t13));
    t15 = *((unsigned int *)t29);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB72;

LAB73:    if (*((unsigned int *)t11) != 0)
        goto LAB74;

LAB75:    t18 = (t41 + 4);
    t20 = *((unsigned int *)t41);
    t21 = (!(t20));
    t22 = *((unsigned int *)t18);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB76;

LAB77:    memcpy(t83, t41, 8);

LAB78:    memset(t84, 0, 8);
    t74 = (t83 + 4);
    t68 = *((unsigned int *)t74);
    t70 = (~(t68));
    t71 = *((unsigned int *)t83);
    t72 = (t71 & t70);
    t73 = (t72 & 1U);
    if (t73 != 0)
        goto LAB91;

LAB92:    if (*((unsigned int *)t74) != 0)
        goto LAB93;

LAB94:    t81 = (t84 + 4);
    t75 = *((unsigned int *)t84);
    t76 = *((unsigned int *)t81);
    t77 = (t75 || t76);
    if (t77 > 0)
        goto LAB95;

LAB96:    memcpy(t111, t84, 8);

LAB97:    t143 = (t111 + 4);
    t144 = *((unsigned int *)t143);
    t145 = (~(t144));
    t146 = *((unsigned int *)t111);
    t147 = (t146 & t145);
    t148 = (t147 != 0);
    if (t148 > 0)
        goto LAB109;

LAB110:    xsi_set_current_line(135, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t3 + 4);
    t13 = *((unsigned int *)t2);
    t14 = (~(t13));
    t15 = *((unsigned int *)t3);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB113;

LAB114:    if (*((unsigned int *)t2) != 0)
        goto LAB115;

LAB116:    t5 = (t8 + 4);
    t20 = *((unsigned int *)t8);
    t21 = *((unsigned int *)t5);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB117;

LAB118:    memcpy(t42, t8, 8);

LAB119:    t32 = (t42 + 4);
    t97 = *((unsigned int *)t32);
    t98 = (~(t97));
    t99 = *((unsigned int *)t42);
    t100 = (t99 & t98);
    t101 = (t100 != 0);
    if (t101 > 0)
        goto LAB131;

LAB132:    xsi_set_current_line(144, ng0);

LAB135:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 28);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2888);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(147, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(148, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);

LAB133:
LAB111:
LAB36:
LAB32:
LAB13:    goto LAB2;

LAB7:    t11 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB9;

LAB8:    *((unsigned int *)t8) = 1;
    goto LAB9;

LAB11:    xsi_set_current_line(78, ng0);

LAB14:    xsi_set_current_line(79, ng0);
    t18 = (t0 + 1848U);
    t19 = *((char **)t18);
    t18 = (t19 + 4);
    t20 = *((unsigned int *)t18);
    t21 = (~(t20));
    t22 = *((unsigned int *)t19);
    t23 = (t22 & t21);
    t24 = (t23 != 0);
    if (t24 > 0)
        goto LAB15;

LAB16:    xsi_set_current_line(97, ng0);

LAB29:    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 28, t4, 28, t5, 28);
    t6 = (t0 + 3208);
    xsi_vlogvar_assign_value(t6, t8, 0, 0, 28);
    xsi_set_current_line(101, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);

LAB17:    goto LAB13;

LAB15:    xsi_set_current_line(80, ng0);

LAB18:    xsi_set_current_line(81, ng0);
    t25 = (t0 + 3368);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = ((char*)((ng3)));
    memset(t29, 0, 8);
    t30 = (t27 + 4);
    if (*((unsigned int *)t30) != 0)
        goto LAB20;

LAB19:    t31 = (t28 + 4);
    if (*((unsigned int *)t31) != 0)
        goto LAB20;

LAB23:    if (*((unsigned int *)t27) > *((unsigned int *)t28))
        goto LAB21;

LAB22:    t33 = (t29 + 4);
    t34 = *((unsigned int *)t33);
    t35 = (~(t34));
    t36 = *((unsigned int *)t29);
    t37 = (t36 & t35);
    t38 = (t37 != 0);
    if (t38 > 0)
        goto LAB24;

LAB25:    xsi_set_current_line(89, ng0);

LAB28:    xsi_set_current_line(90, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 28, t4, 28, t5, 28);
    t6 = (t0 + 3208);
    xsi_vlogvar_assign_value(t6, t8, 0, 0, 28);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);

LAB26:    goto LAB17;

LAB20:    t32 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB22;

LAB21:    *((unsigned int *)t29) = 1;
    goto LAB22;

LAB24:    xsi_set_current_line(82, ng0);

LAB27:    xsi_set_current_line(83, ng0);
    t39 = ((char*)((ng1)));
    t40 = (t0 + 2888);
    xsi_vlogvar_assign_value(t40, t39, 0, 0, 1);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 28, t4, 28, t5, 28);
    t6 = (t0 + 3208);
    xsi_vlogvar_assign_value(t6, t8, 0, 0, 28);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    goto LAB26;

LAB30:    xsi_set_current_line(105, ng0);

LAB33:    xsi_set_current_line(106, ng0);
    t4 = (t0 + 3688);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng4)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 8, t6, 8, t7, 8);
    t9 = (t0 + 3528);
    xsi_vlogvar_assign_value(t9, t8, 0, 0, 8);
    xsi_set_current_line(107, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2888);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 28);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    goto LAB32;

LAB34:    xsi_set_current_line(112, ng0);

LAB37:    xsi_set_current_line(113, ng0);
    t4 = (t0 + 3688);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng6)));
    memset(t8, 0, 8);
    t9 = (t6 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB39;

LAB38:    t10 = (t7 + 4);
    if (*((unsigned int *)t10) != 0)
        goto LAB39;

LAB42:    if (*((unsigned int *)t6) < *((unsigned int *)t7))
        goto LAB41;

LAB40:    *((unsigned int *)t8) = 1;

LAB41:    memset(t29, 0, 8);
    t12 = (t8 + 4);
    t20 = *((unsigned int *)t12);
    t21 = (~(t20));
    t22 = *((unsigned int *)t8);
    t23 = (t22 & t21);
    t24 = (t23 & 1U);
    if (t24 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t12) != 0)
        goto LAB45;

LAB46:    t19 = (t29 + 4);
    t34 = *((unsigned int *)t29);
    t35 = (!(t34));
    t36 = *((unsigned int *)t19);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB47;

LAB48:    memcpy(t47, t29, 8);

LAB49:    t74 = (t47 + 4);
    t75 = *((unsigned int *)t74);
    t76 = (~(t75));
    t77 = *((unsigned int *)t47);
    t78 = (t77 & t76);
    t79 = (t78 != 0);
    if (t79 > 0)
        goto LAB62;

LAB63:    xsi_set_current_line(121, ng0);

LAB66:    xsi_set_current_line(122, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2888);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(123, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 3528);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 8);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 28);
    xsi_set_current_line(125, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);

LAB64:    goto LAB36;

LAB39:    t11 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB41;

LAB43:    *((unsigned int *)t29) = 1;
    goto LAB46;

LAB45:    t18 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB46;

LAB47:    t25 = (t0 + 3688);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = ((char*)((ng4)));
    memset(t41, 0, 8);
    t30 = (t27 + 4);
    if (*((unsigned int *)t30) != 0)
        goto LAB51;

LAB50:    t31 = (t28 + 4);
    if (*((unsigned int *)t31) != 0)
        goto LAB51;

LAB54:    if (*((unsigned int *)t27) > *((unsigned int *)t28))
        goto LAB53;

LAB52:    *((unsigned int *)t41) = 1;

LAB53:    memset(t42, 0, 8);
    t33 = (t41 + 4);
    t38 = *((unsigned int *)t33);
    t43 = (~(t38));
    t44 = *((unsigned int *)t41);
    t45 = (t44 & t43);
    t46 = (t45 & 1U);
    if (t46 != 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t33) != 0)
        goto LAB57;

LAB58:    t48 = *((unsigned int *)t29);
    t49 = *((unsigned int *)t42);
    t50 = (t48 | t49);
    *((unsigned int *)t47) = t50;
    t40 = (t29 + 4);
    t51 = (t42 + 4);
    t52 = (t47 + 4);
    t53 = *((unsigned int *)t40);
    t54 = *((unsigned int *)t51);
    t55 = (t53 | t54);
    *((unsigned int *)t52) = t55;
    t56 = *((unsigned int *)t52);
    t57 = (t56 != 0);
    if (t57 == 1)
        goto LAB59;

LAB60:
LAB61:    goto LAB49;

LAB51:    t32 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB53;

LAB55:    *((unsigned int *)t42) = 1;
    goto LAB58;

LAB57:    t39 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB58;

LAB59:    t58 = *((unsigned int *)t47);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t47) = (t58 | t59);
    t60 = (t29 + 4);
    t61 = (t42 + 4);
    t62 = *((unsigned int *)t60);
    t63 = (~(t62));
    t64 = *((unsigned int *)t29);
    t65 = (t64 & t63);
    t66 = *((unsigned int *)t61);
    t67 = (~(t66));
    t68 = *((unsigned int *)t42);
    t69 = (t68 & t67);
    t70 = (~(t65));
    t71 = (~(t69));
    t72 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t72 & t70);
    t73 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t73 & t71);
    goto LAB61;

LAB62:    xsi_set_current_line(114, ng0);

LAB65:    xsi_set_current_line(115, ng0);
    t80 = ((char*)((ng5)));
    t81 = (t0 + 2888);
    xsi_vlogvar_assign_value(t81, t80, 0, 0, 1);
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 28);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    goto LAB64;

LAB68:    t10 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB70;

LAB72:    *((unsigned int *)t41) = 1;
    goto LAB75;

LAB74:    t12 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB75;

LAB76:    t19 = (t0 + 4008);
    t25 = (t19 + 56U);
    t26 = *((char **)t25);
    t27 = (t0 + 1528U);
    t28 = *((char **)t27);
    t27 = ((char*)((ng8)));
    memset(t42, 0, 8);
    xsi_vlog_unsigned_add(t42, 8, t28, 6, t27, 8);
    memset(t47, 0, 8);
    t30 = (t26 + 4);
    if (*((unsigned int *)t30) != 0)
        goto LAB80;

LAB79:    t31 = (t42 + 4);
    if (*((unsigned int *)t31) != 0)
        goto LAB80;

LAB83:    if (*((unsigned int *)t26) < *((unsigned int *)t42))
        goto LAB82;

LAB81:    *((unsigned int *)t47) = 1;

LAB82:    memset(t82, 0, 8);
    t33 = (t47 + 4);
    t24 = *((unsigned int *)t33);
    t34 = (~(t24));
    t35 = *((unsigned int *)t47);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t33) != 0)
        goto LAB86;

LAB87:    t38 = *((unsigned int *)t41);
    t43 = *((unsigned int *)t82);
    t44 = (t38 | t43);
    *((unsigned int *)t83) = t44;
    t40 = (t41 + 4);
    t51 = (t82 + 4);
    t52 = (t83 + 4);
    t45 = *((unsigned int *)t40);
    t46 = *((unsigned int *)t51);
    t48 = (t45 | t46);
    *((unsigned int *)t52) = t48;
    t49 = *((unsigned int *)t52);
    t50 = (t49 != 0);
    if (t50 == 1)
        goto LAB88;

LAB89:
LAB90:    goto LAB78;

LAB80:    t32 = (t47 + 4);
    *((unsigned int *)t47) = 1;
    *((unsigned int *)t32) = 1;
    goto LAB82;

LAB84:    *((unsigned int *)t82) = 1;
    goto LAB87;

LAB86:    t39 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB87;

LAB88:    t53 = *((unsigned int *)t83);
    t54 = *((unsigned int *)t52);
    *((unsigned int *)t83) = (t53 | t54);
    t60 = (t41 + 4);
    t61 = (t82 + 4);
    t55 = *((unsigned int *)t60);
    t56 = (~(t55));
    t57 = *((unsigned int *)t41);
    t65 = (t57 & t56);
    t58 = *((unsigned int *)t61);
    t59 = (~(t58));
    t62 = *((unsigned int *)t82);
    t69 = (t62 & t59);
    t63 = (~(t65));
    t64 = (~(t69));
    t66 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t66 & t63);
    t67 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t67 & t64);
    goto LAB90;

LAB91:    *((unsigned int *)t84) = 1;
    goto LAB94;

LAB93:    t80 = (t84 + 4);
    *((unsigned int *)t84) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB94;

LAB95:    t85 = (t0 + 4008);
    t86 = (t85 + 56U);
    t87 = *((char **)t86);
    t88 = ((char*)((ng7)));
    memset(t89, 0, 8);
    t90 = (t87 + 4);
    t91 = (t88 + 4);
    t78 = *((unsigned int *)t87);
    t79 = *((unsigned int *)t88);
    t92 = (t78 ^ t79);
    t93 = *((unsigned int *)t90);
    t94 = *((unsigned int *)t91);
    t95 = (t93 ^ t94);
    t96 = (t92 | t95);
    t97 = *((unsigned int *)t90);
    t98 = *((unsigned int *)t91);
    t99 = (t97 | t98);
    t100 = (~(t99));
    t101 = (t96 & t100);
    if (t101 != 0)
        goto LAB99;

LAB98:    if (t99 != 0)
        goto LAB100;

LAB101:    memset(t103, 0, 8);
    t104 = (t89 + 4);
    t105 = *((unsigned int *)t104);
    t106 = (~(t105));
    t107 = *((unsigned int *)t89);
    t108 = (t107 & t106);
    t109 = (t108 & 1U);
    if (t109 != 0)
        goto LAB102;

LAB103:    if (*((unsigned int *)t104) != 0)
        goto LAB104;

LAB105:    t112 = *((unsigned int *)t84);
    t113 = *((unsigned int *)t103);
    t114 = (t112 & t113);
    *((unsigned int *)t111) = t114;
    t115 = (t84 + 4);
    t116 = (t103 + 4);
    t117 = (t111 + 4);
    t118 = *((unsigned int *)t115);
    t119 = *((unsigned int *)t116);
    t120 = (t118 | t119);
    *((unsigned int *)t117) = t120;
    t121 = *((unsigned int *)t117);
    t122 = (t121 != 0);
    if (t122 == 1)
        goto LAB106;

LAB107:
LAB108:    goto LAB97;

LAB99:    *((unsigned int *)t89) = 1;
    goto LAB101;

LAB100:    t102 = (t89 + 4);
    *((unsigned int *)t89) = 1;
    *((unsigned int *)t102) = 1;
    goto LAB101;

LAB102:    *((unsigned int *)t103) = 1;
    goto LAB105;

LAB104:    t110 = (t103 + 4);
    *((unsigned int *)t103) = 1;
    *((unsigned int *)t110) = 1;
    goto LAB105;

LAB106:    t123 = *((unsigned int *)t111);
    t124 = *((unsigned int *)t117);
    *((unsigned int *)t111) = (t123 | t124);
    t125 = (t84 + 4);
    t126 = (t103 + 4);
    t127 = *((unsigned int *)t84);
    t128 = (~(t127));
    t129 = *((unsigned int *)t125);
    t130 = (~(t129));
    t131 = *((unsigned int *)t103);
    t132 = (~(t131));
    t133 = *((unsigned int *)t126);
    t134 = (~(t133));
    t135 = (t128 & t130);
    t136 = (t132 & t134);
    t137 = (~(t135));
    t138 = (~(t136));
    t139 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t139 & t137);
    t140 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t140 & t138);
    t141 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t141 & t137);
    t142 = *((unsigned int *)t111);
    *((unsigned int *)t111) = (t142 & t138);
    goto LAB108;

LAB109:    xsi_set_current_line(129, ng0);

LAB112:    xsi_set_current_line(130, ng0);
    t149 = ((char*)((ng5)));
    t150 = (t0 + 2888);
    xsi_vlogvar_assign_value(t150, t149, 0, 0, 1);
    xsi_set_current_line(131, ng0);
    t2 = (t0 + 3368);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3208);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 28);
    xsi_set_current_line(132, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(133, ng0);
    t2 = (t0 + 4008);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3848);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    goto LAB111;

LAB113:    *((unsigned int *)t8) = 1;
    goto LAB116;

LAB115:    t4 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB116;

LAB117:    t6 = (t0 + 3048);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    t10 = ((char*)((ng1)));
    memset(t29, 0, 8);
    t11 = (t9 + 4);
    t12 = (t10 + 4);
    t23 = *((unsigned int *)t9);
    t24 = *((unsigned int *)t10);
    t34 = (t23 ^ t24);
    t35 = *((unsigned int *)t11);
    t36 = *((unsigned int *)t12);
    t37 = (t35 ^ t36);
    t38 = (t34 | t37);
    t43 = *((unsigned int *)t11);
    t44 = *((unsigned int *)t12);
    t45 = (t43 | t44);
    t46 = (~(t45));
    t48 = (t38 & t46);
    if (t48 != 0)
        goto LAB123;

LAB120:    if (t45 != 0)
        goto LAB122;

LAB121:    *((unsigned int *)t29) = 1;

LAB123:    memset(t41, 0, 8);
    t19 = (t29 + 4);
    t49 = *((unsigned int *)t19);
    t50 = (~(t49));
    t53 = *((unsigned int *)t29);
    t54 = (t53 & t50);
    t55 = (t54 & 1U);
    if (t55 != 0)
        goto LAB124;

LAB125:    if (*((unsigned int *)t19) != 0)
        goto LAB126;

LAB127:    t56 = *((unsigned int *)t8);
    t57 = *((unsigned int *)t41);
    t58 = (t56 & t57);
    *((unsigned int *)t42) = t58;
    t26 = (t8 + 4);
    t27 = (t41 + 4);
    t28 = (t42 + 4);
    t59 = *((unsigned int *)t26);
    t62 = *((unsigned int *)t27);
    t63 = (t59 | t62);
    *((unsigned int *)t28) = t63;
    t64 = *((unsigned int *)t28);
    t66 = (t64 != 0);
    if (t66 == 1)
        goto LAB128;

LAB129:
LAB130:    goto LAB119;

LAB122:    t18 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB123;

LAB124:    *((unsigned int *)t41) = 1;
    goto LAB127;

LAB126:    t25 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t25) = 1;
    goto LAB127;

LAB128:    t67 = *((unsigned int *)t42);
    t68 = *((unsigned int *)t28);
    *((unsigned int *)t42) = (t67 | t68);
    t30 = (t8 + 4);
    t31 = (t41 + 4);
    t70 = *((unsigned int *)t8);
    t71 = (~(t70));
    t72 = *((unsigned int *)t30);
    t73 = (~(t72));
    t75 = *((unsigned int *)t41);
    t76 = (~(t75));
    t77 = *((unsigned int *)t31);
    t78 = (~(t77));
    t65 = (t71 & t73);
    t69 = (t76 & t78);
    t79 = (~(t65));
    t92 = (~(t69));
    t93 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t93 & t79);
    t94 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t94 & t92);
    t95 = *((unsigned int *)t42);
    *((unsigned int *)t42) = (t95 & t79);
    t96 = *((unsigned int *)t42);
    *((unsigned int *)t42) = (t96 & t92);
    goto LAB130;

LAB131:    xsi_set_current_line(136, ng0);

LAB134:    xsi_set_current_line(137, ng0);
    t33 = ((char*)((ng7)));
    t39 = (t0 + 3208);
    xsi_vlogvar_assign_value(t39, t33, 0, 0, 28);
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 3048);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2888);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(139, ng0);
    t2 = (t0 + 3688);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3528);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 8);
    xsi_set_current_line(140, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    t2 = (t0 + 3848);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 8);
    goto LAB133;

}


extern void work_m_00000000000233415656_2000342482_init()
{
	static char *pe[] = {(void *)Cont_45_0,(void *)Always_47_1,(void *)Always_75_2};
	xsi_register_didat("work_m_00000000000233415656_2000342482", "isim/top_tb_isim_beh.exe.sim/work/m_00000000000233415656_2000342482.didat");
	xsi_register_executes(pe);
}
